  <!-- Footer -->
  <footer class="footer">
      Dashmin © 2020 created by <a href="https://www.themelooks.com/"> ThemeLooks</a>
  </footer>
  <!-- End Footer -->
  </div>
  <!-- End wrapper -->

  <!-- ======= BEGIN GLOBAL MANDATORY SCRIPTS ======= -->
  <script src="{{ asset('admin') }}/assets/js/jquery.min.js"></script>
  <script src="{{ asset('admin') }}/assets/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="{{ asset('admin') }}/assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
  <script src="{{ asset('admin') }}/assets/js/script.js"></script>
  <!-- ======= BEGIN GLOBAL MANDATORY SCRIPTS ======= -->

  @yield('JS')
  </body>

  </html>
