  <!-- Footer -->
  <footer class="footer">
      Dashmin © 2020 created by <a href="https://www.themelooks.com/"> ThemeLooks</a>
  </footer>
  <!-- End Footer -->
  </div>
  <!-- End wrapper -->

  <!-- ======= BEGIN GLOBAL MANDATORY SCRIPTS ======= -->
  <script src="<?php echo e(asset('admin')); ?>/assets/js/jquery.min.js"></script>
  <script src="<?php echo e(asset('admin')); ?>/assets/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo e(asset('admin')); ?>/assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
  <script src="<?php echo e(asset('admin')); ?>/assets/js/script.js"></script>
  <!-- ======= BEGIN GLOBAL MANDATORY SCRIPTS ======= -->

  <?php echo $__env->yieldContent('JS'); ?>
  </body>

  </html>
<?php /**PATH /media/asd/asd/Project/latusurya/resources/views/admin/footer.blade.php ENDPATH**/ ?>