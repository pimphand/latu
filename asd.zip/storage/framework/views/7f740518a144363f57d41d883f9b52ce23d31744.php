<!-- footer -->
<footer>
    <div class="footer-top-wrap black-bg pt-90 pb-35">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="footer-widget mb-50 pr-80">
                        <div class="logo mb-25">
                            <a href="#"><img src="<?php echo e(asset('frontend')); ?>/img/logo/w_logo.png" alt="Logo"></a>
                        </div>
                        <div class="footer-social">
                            <ul>
                                <li> <a href="https://www.instagram.com/latusuryaabadi">
                                        <span><i class="fa fa-instagram"></i></span></a>
                                </li><li>    <a href="https://www.facebook.com/Latu-Surya-Abadi-111245510418701/">
                                        <span><i class="fa fa-facebook"></i></span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6">
                    <div class="footer-widget mb-50">
                        <div class="fw-title mb-30">
                            <h5>PRODUCT List</h5>
                        </div>
                        <div class="fw-link">
                            <ul>
                                <li><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                                <li><a href="<?php echo e(route('about')); ?>">Tentang Kami</a></li>
                                <li><a href="<?php echo e(route('produk')); ?>">Produk</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-3 col-md-3 col-sm-6">
                    <div class="footer-widget mb-50">
                        <div class="fw-title mb-30">
                            <h5>&nbsp;</h5>
                        </div>
                        <div class="fw-link">
                            <ul>
                                <li><a href="<?php echo e(route('berita')); ?>">Berita</a></li>
                                <li><a href="<?php echo e(route('kontak')); ?>">Kontak</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                    <div class="footer-widget mb-50">
                        <div class="fw-title mb-30">
                            <h5>Produk</h5>
                        </div>
                        <div class="fw-link">
                            <ul>
                                <li><a href="<?php echo e(route('produk')); ?>">Oli</a></li>
                                <li><a href="<?php echo e(route('produk')); ?>">Ban</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="copyright-wrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="copyright-text">
                        <p>Copyright © 2021 <a href="https://dmptdev.com" target="_blank">Dmptdev</a> All Rights Reserved.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 d-none d-md-block">
                    <div class="payment-method-img text-right">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer-end -->
<?php /**PATH /media/asd/asd/Project/latusurya/resources/views/frontend/component/footer.blade.php ENDPATH**/ ?>