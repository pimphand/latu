<?php $__env->startSection('slider'); ?>
    <section class="breadcrumb-area d-flex align-items-center"
        data-background="<?php echo e(asset('frontend')); ?>/img/bg/breadcrumb_bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-wrap text-center">
                        <h2>Berita</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Berita</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb-area-end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="inner-blog-area gray-light-bg pt-120 pb-120">
        <div class="container">
            <div class="inner-blog-wrap">
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-11">
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="inner-single-blog-post mb-50">
                                <div class="blog-thumb mb-30">
                                    <a href="<?php echo e(route('berita.detail', $item->id)); ?>">
                                        <img src="<?php echo e(asset('storage/news/' . $item->image)); ?>"
                                            alt="<?php echo e(config('app.name', 'Latu Surya Abadi')); ?>" width="200px">
                                    </a>
                                </div>
                                <div class="inner-blog-content">
                                    <h5><a href="#"><?php echo e($item->name); ?></a></h5>
                                    <div class="blog-meta mb-20">
                                        <ul>
                                            <li><i class="far fa-calendar"></i><?php echo e($item->created_at->format('d M Y')); ?>

                                            </li>
                                        </ul>
                                    </div>
                                    <p><?php echo Str::limit($item->body, 100); ?></p>
                                    <a href="<?php echo e(route('berita.detail', $item->id)); ?>">Lanjut Baca<i
                                            class="fas fa-chevron-right"></i></a>
                                    
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-lg-4 col-md-8">
                        <aside class="blog-sidebar">
                            <div class="widget mb-40">
                                <div class="sidebar-rc-post">
                                    <h4 class="blog-sidebar-title">Ban</h4>
                                    <ul>
                                        <?php $__currentLoopData = $ban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <div class="rc-post-thumb">
                                                    <a href="<?php echo e(route('produk.detail', $b->id)); ?>"><img width="90px"
                                                            src="<?php echo e(asset('storage/produk/' . $b->image)); ?>"
                                                            alt="<?php echo e(config('app.name', 'Latu Surya Abadi')); ?> <?php echo e($b->name); ?>"></a>
                                                </div>
                                                <div class="rc-post-content">
                                                    <h5><a href="#"><?php echo e($b->name); ?></a></h5>
                                                    <ul class="rc-post-meta">
                                                        <li><?php echo e($b->category->name); ?></li>
                                                    </ul>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget mb-40">
                                <div class="sidebar-cat">
                                    <h4 class="blog-sidebar-title">Oli</h4>
                                    <ul>
                                        <?php $__currentLoopData = $oli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <div class="rc-post-thumb">
                                                    <a href="<?php echo e(route('produk.detail', $o->id)); ?>"><img width="90px"
                                                            src="<?php echo e(asset('storage/produk/' . $o->image)); ?>"
                                                            alt="<?php echo e(config('app.name', 'Latu Surya Abadi')); ?> <?php echo e($o->name); ?>"></a>
                                                </div>
                                                <div class="rc-post-content">
                                                    <h5><a href="#"><?php echo e($o->name); ?></a></h5>
                                                    
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.component.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/asd/asd/Project/latusurya/resources/views/frontend/berita.blade.php ENDPATH**/ ?>