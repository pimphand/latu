<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card mb-30">
                        <div class="card-body">
                            <?php if($message = Session::get('danger')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                            <div class="d-sm-flex justify-content-between align-items-center">
                                <h4 class="font-20">List Service</h4>
                                <a href="<?php echo e(route('service.create')); ?>">
                                    <button class="btn btn-info">Tambah</button></a>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <!-- Invoice List Table -->
                            <table class="text-nowrap table-contextual dh-table">
                                <thead>
                                    <tr>
                                        <th># </th>
                                        <th>Nama</th>
                                        <th>Icon</th>
                                        <th>Deskripsi </th>
                                        <th>aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($n->name); ?></td>
                                            <td>
                                                <a href="<?php echo e(asset('storage/service/' . $n->icon)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset('storage/service/' . $n->icon)); ?>" alt=""
                                                        width="150">
                                                </a>
                                            </td>
                                            <td><?php echo $n->description; ?></td>
                                            <td>
                                                <a href="<?php echo e(route('service.edit', ['service' => $n->id])); ?>">
                                                    <button class="btn btn-primary"><i class="fa fa-pencil"></i></button>
                                                </a>
                                                <form action="<?php echo e(route('service.destroy', ['service' => $n->id])); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger bg-danger">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" class="text-center p-5">
                                                Belum ada berita
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <!-- End Invoice List Table -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/asd/asd/Project/latusurya/resources/views/admin/service/index.blade.php ENDPATH**/ ?>