<?php $__env->startSection('slider'); ?>
    <section class="breadcrumb-area d-flex align-items-center"
        data-background="<?php echo e(asset('frontend')); ?>/img/bg/breadcrumb_bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-wrap text-center">
                        <h2>Produk</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Produk</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb-area-end -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="product-area gray-bg pt-120 pb-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8">
                    <div class="section-title text-center mb-55">
                        <h3>Ban</h3>
                    </div>
                </div>
            </div>
            <div class="t-product-wrap">
                <div class="row">
                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->category_id == 2): ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="single-product t-single-product mb-30">
                                    <div class="product-img">
                                        <a href="<?php echo e(route('produk.detail', $item->id)); ?>"><img
                                                src="<?php echo e(asset('storage/produk/' . $item->image)); ?>" alt="img"></a>
                                    </div><br><br><br>
                                    <div class="t-product-overlay">
                                        <h5><a href="<?php echo e(route('produk.detail', $item->id)); ?>"><?php echo e($item->name); ?></a></h5>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-xl-8">
                    <div class="section-title text-center mb-55">
                        <h3>Olie</h3>
                    </div>
                </div>
            </div>
            <div class="t-product-wrap">
                <div class="row">
                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->category_id == 1): ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="single-product t-single-product mb-30">
                                    <div class="product-img">
                                        <a href="<?php echo e(route('produk.detail', $item->id)); ?>"><img
                                                src="<?php echo e(asset('storage/produk/' . $item->image)); ?>" alt="img"></a>
                                    </div><br><br><br>
                                    <div class="t-product-overlay">
                                        <h5><a href="<?php echo e(route('produk.detail', $item->id)); ?>"><?php echo e($item->name); ?></a></h5>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.component.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/asd/asd/Project/latusurya/resources/views/frontend/produk.blade.php ENDPATH**/ ?>