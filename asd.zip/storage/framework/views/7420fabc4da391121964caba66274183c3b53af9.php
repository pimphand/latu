<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card mb-30">
                        <div class="card-body">
                            <div class="d-sm-flex justify-content-between align-items-center">
                                <h4 class="font-20">Pesan Terbaru</h4>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <!-- Invoice List Table -->
                            <table class="text-nowrap bg-white dh-table">
                                <thead>
                                    <tr>
                                        <th># </th>
                                        <th>Nama </th>
                                        <th>Nomor Telepon </th>
                                        <th>Pesan </th>
                                        <th>Status </th>
                                        <th>Tanggal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($m->name); ?></td>
                                            <td><?php echo e($m->phone); ?></td>
                                            <td><?php echo e($m->messages); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('inbox.update', $m->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="status-btn un_paid">baca</button>
                                                </form>
                                            </td>
                                            <td>
                                                <?php echo e(\Carbon\Carbon::parse($m->created_at)->format('d M Y')); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" class="text-center p-5">
                                                Belum ada pesan baru
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <!-- End Invoice List Table -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
<!-- ======= BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS ======= -->
<script src="<?php echo e(asset('admin')); ?>/assets/plugins/apex/apexcharts.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/assets/plugins/apex/custom-apexcharts.js"></script>
<!-- ======= End BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS ======= -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/asd/asd/Project/latusurya/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>