<?php $__env->startSection('slider'); ?>
    <section class="slider-area slider-bg" data-background="<?php echo e(asset('frontend')); ?>/img/slider/slider_bg02.jpg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-10">
                    <div class="slider-content text-center mb-45">
                        <h2>Latu Surya Abadi</h2>
                        <p>Latu Surya Abadi merupakan bengkel otomotif yang bergerak dalam bidang ban dan oli , baik
                            itu perawatan, perbaikan, maupun penjualan. Bengkel Latu Surya Abadi berlokasi di Jl. PB.
                            Sudirman RT02/RW08 Ngawi sejak tahun 2013.</p>
                    </div>
                </div>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-xl-10">
                    <div class="slider-dashboard">
                        <div class="dashboard-active">
                            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-dashboard">
                                    <a href="<?php echo e(route('produk')); ?>">
                                        <img src="<?php echo e(asset('storage/slider/' . $slide->url)); ?>"
                                            alt="<?php echo e(config('app.name', 'Latu Surya Abadi')); ?>" width="400px">
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="features-items-area features-items-p">
        <div class="container">
            
            
        </div>
    </section>
    <!-- features-items-end -->
    <!-- product-area -->
    <section class="product-area product-bg pb-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-9">
                    <div class="section-title text-center mb-30">
                        <h2>Produk</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 text-center">
                    <div class="product-menu mb-60">
                        <button class="active" data-filter="*">Semua Kategori</button>
                        <?php $__currentLoopData = $kat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button class="" data-filter=".<?php echo e($k->name); ?>"><?php echo e($k->name); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="row product-active">
                <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-4 col-md-6 grid-item cat-three <?php echo e($p->category->name); ?>">
                        <div class="single-product mb-30">
                            <a href="<?php echo e(route('produk.detail', $p->id)); ?>"><img
                                    src="<?php echo e(asset('storage/produk/' . $p->image)); ?>"
                                    alt="<?php echo e(config('app.name', 'Latu Surya Abadi')); ?>" width="300px"></a>
                            <div class="product-overlay">
                                <h5><a href="#"><?php echo e($p->name); ?></a></h5>
                                <span><?php echo e($p->category->name); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="product-btn text-center mt-30">
                        <a href="<?php echo e(route('produk')); ?>" class="btn">Semua Produk</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="product-bg-shape">
            <img src="<?php echo e(asset('frontend')); ?>/img/shape/product_shape.png" alt="img">
        </div>
    </section>
    <!-- testimonial-area-end -->
    <!-- services-area -->
    <section class="services-area services-bg pt-115 pb-70"
        data-background="<?php echo e(asset('frontend')); ?>/img/bg/services_bg.jpg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6">
                    <div class="section-title white-title text-center mb-55">
                        <h2>Service / Layanan</h2>
                        <p>Selain menjual Olie dan Ban Latu Surya Abadi juga melayani service seperti berikut ini :</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0.2s">
                    <div class="single-services mb-50">
                        <div class="services-icon mb-30">
                            <img src="<?php echo e(asset('frontend')); ?>/img/icon/engine (2).png" alt="img" width="60px">
                        </div>
                        <div class="services-content">
                            <h4>Tune Up Carbon</h4>
                            
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0.2s">
                    <div class="single-services mb-50">
                        <div class="services-icon mb-30">
                            <img src="<?php echo e(asset('frontend')); ?>/img/icon/car.png" alt="img" width="60px">
                        </div>
                        <div class="services-content">
                            <h4>Tune Up Biasa</h4>
                            
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0.2s">
                    <div class="single-services mb-50">
                        <div class="services-icon mb-30">
                            <img src="<?php echo e(asset('frontend')); ?>/img/icon/bolt.png" alt="img" width="60px">
                        </div>
                        <div class="services-content">
                            <h4>Kelistrikan</h4>
                            
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0.2s">
                    <div class="single-services mb-50">
                        <div class="services-icon mb-30">
                            <img src="<?php echo e(asset('frontend')); ?>/img/icon/car-battery.png" alt="img" width="60px">
                        </div>
                        <div class="services-content">
                            <h4>Scan Ecu</h4>
                            
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0.4s">
                    <div class="single-services mb-50">
                        <div class="services-icon mb-30">
                            <img src="<?php echo e(asset('frontend')); ?>/img/icon/engine.png" alt="img" width="60px">
                        </div>
                        <div class="services-content">
                            <h4>Diesel Purging</h4>
                            
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0.2s">
                    <div class="single-services mb-50">
                        <div class="services-icon mb-30">
                            <img src="<?php echo e(asset('frontend')); ?>/img/icon/3d-printer.png" alt="img" width="60px">
                        </div>
                        <div class="services-content">
                            <h4>Service/Perbaikan kendaraan lainnya</h4>
                            
                        </div>
                    </div>
                </div>
                
                
            </div>
        </div>
    </section>
    <!-- plugin-area-end -->
    <!-- blog-area -->
    <section class="blog-area blog-bg pt-115 pb-90">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-9">
                    <div class="section-title text-center mb-55">
                        <h2>Berita Terbaru</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-blog-post mb-30">
                            <div class="blog-thumb">
                                <a href="#"><img src="<?php echo e(asset('frontend')); ?>/img/blog/blog_thumb01.jpg" alt="img"></a>
                            </div>
                            <div class="blog-content">
                                <div class="bc-top-wrap fix mb-25">
                                    <div class="b-post-date">
                                        <h6>19</h6>
                                        <span>Aug, 2019</span>
                                    </div>
                                    <div class="b-top-content fix">
                                        <h5><a href="#">Global Marketplace Market</a></h5>
                                        <div class="blog-meta">
                                            <ul>
                                                <li><a href="#"><i class="far fa-user"></i>Admin</a></li>
                                                <li><i class="far fa-comments"></i>19</li>
                                                <li><i class="far fa-heart"></i>457</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <p>Simply dummy textht the prihntig and tyesetting industry. Lorem Ipsum has been.</p>
                                <a href="#">Read More <span>+</span></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-lg-12 col-md-6">
                        <div class="single-blog-post mb-30">
                            <div class="blog-content">
                                <div class="b-top-content fix text-center">
                                    <h5>Tidak ada berita</h5>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- blog-area-end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.component.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/asd/asd/Project/latusurya/resources/views/frontend/home.blade.php ENDPATH**/ ?>