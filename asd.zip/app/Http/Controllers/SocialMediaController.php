<?php

namespace App\Http\Controllers;

use App\Models\Social_Media;
use Illuminate\Http\Request;

class SocialMediaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Social_Media  $social_Media
     * @return \Illuminate\Http\Response
     */
    public function show(Social_Media $social_Media)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Social_Media  $social_Media
     * @return \Illuminate\Http\Response
     */
    public function edit(Social_Media $social_Media)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Social_Media  $social_Media
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Social_Media $social_Media)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Social_Media  $social_Media
     * @return \Illuminate\Http\Response
     */
    public function destroy(Social_Media $social_Media)
    {
        //
    }
}
